/**********************************************************************************/
/* Header file ADC.h                                                              */
/**********************************************************************************/
#ifndef _ADC_H_
#define _ADC_H_



/* declare initialisation function ADC_Init */
extern void ADC_Init(void);


/* declare read function ADC_Read*/
extern unsigned short ADC_Read(unsigned short chan);



#endif _ADC_H_
