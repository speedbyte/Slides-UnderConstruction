/* Example program for the Wytec Dragon 12 (MC9S12DP256C) */

#include <mc9s12dp256.h>        /* derivative information */
#include "pll.h"								/* defines _BUSCLOCK, sets bus frequency to _BUSCLOCK MHz */
#include "timer.h"							/* TOC7_Init, TOC7_ISR */
#include "adc.h"                /* ADC_Read */
#include "sci1.h"               /* support for SCI1 */


/*** main program ***/
void main(void) {

unsigned int  Data;

  /* set system clock frequency to _BUSCLOCK MHz (24 or 4) */
  PLL_Init();

  /* configure port B as output */
  DDRB  = 0xff;

  /* initialise serial communication interface SCI1 */
  SCI1_Init(BAUD_115200);   // capped at 9600, if PLL inactive (4 MHz bus)

  /* activate ADC, start ADC */
  ADC_Init();

  /* activate timer TOC7, allow interrupts */
  TOC7_Init();        // TOC7 interrupt periodically starts ADC
  asm cli

  /* Output something on SCI1 */
  SCI1_OutString("Data logger\n\r");
  
  /* forever */
  for(;;) {
    
    /* read ADC, this blocks until the TOC7 interrupt has happened */
    Data = ADC_Read();
    
    SCI1_OutString("Current value AD channel AN07: "); 
    SCI1_OutUHex(Data);
    SCI1_OutString("\n\r");
    
    PORTB ^= 0x01;          // toggle port B bit 0

  }
    
}