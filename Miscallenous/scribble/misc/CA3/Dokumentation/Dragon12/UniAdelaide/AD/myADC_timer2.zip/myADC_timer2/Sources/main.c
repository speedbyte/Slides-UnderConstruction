/* Example program for the Wytec Dragon 12 (MC9S12DP256C) */

#include <mc9s12dp256.h>        /* derivative information */
#include "pll.h"								/* defines _BUSCLOCK, sets bus frequency to _BUSCLOCK MHz */
#include "timer.h"							/* TOC7_Init, TOC7_ISR */
#include "adc.h"                /* ADC_Init, ADC_Start */
#include "sci1.h"               /* support for SCI1 */


/*** main program ***/
void main(void) {

  /* set system clock frequency to _BUSCLOCK MHz (24 or 4) */
  PLL_Init();

  /* configure port B as output */
  DDRB  = 0xff;

  /* initialise serial communication interface SCI1 */
  SCI1_Init(BAUD_115200);   // capped at 9600, if PLL inactive (4 MHz bus)

  /* activate ADC */
  ADC_Init();

  /* start first conversion */
  ADC_Start(0x87);        // channel AN07, right-aligned

  /* activate timer TOC7, allow interrupts */
  TOC7_Init();
  asm cli

  /* Output something on SCI1 */
  SCI1_OutString("Data logger\n\r");

  /* forever   (everything's been moved into the timer ISR) */
  for(;;) {}
    
}