/*  Rti Interrupt on Dragon12 - C version

    Computerarchitektur 3
    (C) 2007 J. Friedrich, W. Zimmermann
    Hochschule Esslingen

    Author:  W.Zimmermann, July 21, 2007  
*/

#include <hidef.h>                      //Common defines
#include <mc9s12dp256.h>                //CPU specific defines

#pragma LINK_INFO DERIVATIVE "mc9s12dp256b"

#define SEVEN_SEGS_OFF                  //Uncomment this to turn seven segment display off

void main(void) 
{   EnableInterrupts;                   //Allow interrupts for debugger

    DDRT  = 0x20;                       //Port T.5 as output (Buzzer)
    PTT   = 0x20;                       //Turn on

    RTICTL = 0x7F;                      //RTI interrupt period
    CRGINT = CRGINT | 0x80;             //Set RTIE bit in CRGINT --> Enable RTIE interrupts

    for(;;);                            //Endless loop
}

interrupt 7 void mRtiISR (void) 
{   PTT = ~PTT;                         //Toggle Buzzer on Port T.5    
    CRGFLG = CRGFLG | 0x80;             //Reset Interrupt Flag (bit 7 in CRGFLG)
}
