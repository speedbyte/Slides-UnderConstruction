/* ************************ timer.c ****************************
 * Simple timer (TC7)
 * ************************************************************ */
 
#include <mc9s12dp256.h>        /* derivative information */


/* interrupt handler, timer 7 (vector 15) */
__interrupt void TOC7_ISR(void) {

  TFLG1 = 0x80;          // acknowledge interrupt (clears C7F)
  
}

// the interrupt handler TOC7handler is called every 'timerValue' ticks
// (note: the period of the LED should be twice as long [on phase, off phase])
// example:  timerValue = 40000, prescale value = 001 (divide-by-2 -> 500 ns)
//           timer period : 40000 * 500 ns = 20 ms

#define timerValue 0xFFFF

void TOC7_Init(void){
  
  asm sei             // beginning of atomic unit

  TIOS   = 0x80;      // Configure channel 7 for output compare (OC) mode
  TCTL1 &= 0x3F;      // 00xx.xxxx -> OM7 = OM7 = 0 (disconnect pin 'IOC7' from o/p logic)
  OC7M   = 0x00;      // do not affect any of the linked output pins (IOC0 - IOC6)
  
  /* Bottom three bits of TSCR2 (PR2,PR1,PR0) determine TCNT period
           divider   resolution   maximum period  
    000      1          42ns         2.73ms
    001      2          84ns         5.46ms
    010      4         167ns         10.9ms
    011      8         333ns         21.8ms
    100     16         667ns         43.7ms
    101     32        1.33us         87.4ms
    110     64        2.67us        174.8ms
    111    128        5.33us        349.5ms    */ 
  TSCR2  = 0x0C;      // Divide clock by 16, disable TOI (timer overflow interrupt)
                      // TCRE = 1 (reset TCNT upon output compare match of channel 7)


  TC7 = timerValue;   // initialize timer register (channel 7)
  
  //TFLG1 = 0x80;       // initially clear C7F (event flag for channel 7)
  TIE   = 0x80;       // enable channel 7 interrupt
  
  TSCR1  = 0x80;      // enable timer (set TEN bit)

  asm cli             // end of atomic unit
}