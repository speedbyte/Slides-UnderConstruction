/* MiniDragon+ */

#include <mc9s12dp256.h>        /* derivative information */
#include "pll.h"								/* defines _BUSCLOCK, sets bus frequency to _BUSCLOCK MHz */
#include "sci1.h"               /* support for SCI1 */
#include "pwm.h"                /* include the PWM functions */


/* prompt the user to enter a new duty cycle percent */
unsigned short promptForDutyCycle(void) {

  SCI1_OutString("\r\nPlease enter duty cycle (0-100): ");
  return SCI1_InUDec();
  
}

void main(void) {

float           period = 0.002;     /* seconds */
unsigned char   channel = 1;        /* pin 3 */
unsigned char   use16bit = 1;       /* use 16bit accuracy */
unsigned short  dutyPercent = 3;    /* percent */

  /* set system clock frequency to _BUSCLOCK MHz (24 or 4) */
  PLL_Init();

  /* initialise serial communication interface SCI1 */
  SCI1_Init(BAUD_115200);

  /* init PWM using specified channel, precision, period, and (default)
     duty cycle */
  PWM_Init(channel, use16bit, period, dutyPercent/100.0);
  PWM_Init(channel+2, use16bit, period*10, dutyPercent/100.0);
  PWM_Init(channel+4, use16bit, period*100, dutyPercent/100.0);

  /* forever prompt for new duty cycle */
  while(1) {
  
    dutyPercent = promptForDutyCycle();
    PWM_SetDuty(channel, dutyPercent/100.0);
    PWM_SetDuty(channel+2, dutyPercent/100.0);
    PWM_SetDuty(channel+4, dutyPercent/100.0);
    
  }
  
}
