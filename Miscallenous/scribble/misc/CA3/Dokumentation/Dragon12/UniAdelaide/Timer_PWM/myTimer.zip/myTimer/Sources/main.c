/* Example program for the Wytec Dragon 12 (MC9S12DP256C) */

#include <mc9s12dp256.h>        /* derivative information */
#include "pll.h"								/* defines _BUSCLOCK, sets bus frequency to _BUSCLOCK MHz */
#include "timer.h"							/* TOC7_Init, TOC7_ISR */


void main(void) {

  /* set system clock frequency to _BUSCLOCK MHz (24 or 4) */
  PLL_Init();

  /* set port B as output (LEDs) */
  DDRB  = 0xff;       // Port B is output

  /* activate timer TOC7 */
  TOC7_Init();

  /* allow all interrupts to happen */
  asm cli

  /* forever */
  for(;;) {}
  
}