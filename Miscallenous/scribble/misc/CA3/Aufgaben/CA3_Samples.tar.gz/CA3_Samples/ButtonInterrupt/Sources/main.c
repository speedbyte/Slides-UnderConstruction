/*  Button Interrupt on Dragon12 - C version

    Computerarchitektur 3
    (C) 2007 J. Friedrich, W. Zimmermann
    Hochschule Esslingen

    Author:  W.Zimmermann, July 21, 2007  
*/

#include <hidef.h>                      //Common defines
#include <mc9s12dp256.h>                //CPU specific defines


#pragma LINK_INFO DERIVATIVE "mc9s12dp256b"

#define SEVEN_SEGS_OFF                  //Uncomment this to turn seven segment display off

void main(void) 
{   EnableInterrupts;                   //Allow interrupts

    DDRJ_DDRJ1 = 1;                     //Port J.1 as output
    PTJ_PTJ1   = 0;                     //J.1=0 --> Activate LEDs

    DDRP = DDRP | 0x0F;                 //Port P.3..0 as outputs (seven segment display control)
    PTP  = PTP  | 0x0F;                 //Turn off seven segment display
    
    DDRB  = 0xFF;                       //Port B.7...0 as outputs (LEDs)
    PORTB = 0x55;                       //Turn on every second LED

    DDRH = 0x00;                        //Port H as inputs
    PPSH = 0x01;                        //'1' triggers interrupt on positive slope 
    PIEH = 0x01;                        //'1' enables interrupt for the respective input
    
    asm NOP

    for(;;)                             //Endless loop
    {           
    }
}

interrupt 25 void ButtonISR(void) 
{   PORTB = ~PORTB;                     //Toggle LEDs on Port B
    PIFH = 0x01;                        //'1' clears the interrupt flag
}
