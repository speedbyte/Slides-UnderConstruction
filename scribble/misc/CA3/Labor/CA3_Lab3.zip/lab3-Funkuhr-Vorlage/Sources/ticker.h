/*  Header for ticker module

    Computerarchitektur 3
    (C) 2007 J. Friedrich, W. Zimmermann
    Hochschule Esslingen

    Author:  W.Zimmermann, Aug. 09, 2007  
*/

// Public functions, for details see ticker.asm
void initTicker(void);
