/* Example program for the Wytec Dragon 12 (MC9S12DP256C) */

#include <mc9s12dp256.h>        /* derivative information */
#include "pll.h"								/* defines _BUSCLOCK, sets bus frequency to _BUSCLOCK MHz */
#include "sci1.h"               /* support for SCI1 */


void main(void) {

  /* set system clock frequency to _BUSCLOCK MHz (24 or 4) */
  PLL_Init();

  DDRB  = 0xff;       // Port B is output
  PORTB = 0x55;       // switch on every other LED
  
  /* initialise serial communication interface SCI1 */
  SCI1_Init(BAUD_115200);   // capped at 9600, if PLL inactive (4 MHz bus)
  
  /* test output on SCI1 */
  SCI1_OutString("Hello World\n\r");

  /* forever */
  for(;;){}
}
