/* Example program for the Wytec Dragon 12 (MC9S12DP256C) */

#include <mc9s12dp256.h>        /* derivative information */
#include "pll.h"								/* defines _BUSCLOCK, sets bus frequency to _BUSCLOCK MHz */
#include "adc.h"                /* ADC_Init, ADC_Read */


void main(void) {

unsigned int  Data, i;
unsigned char led;

  /* set system clock frequency to _BUSCLOCK MHz (24 or 4) */
  PLL_Init();

  /* set port B as output (LEDs) */
  DDRB  = 0xff;       // Port B is output

  /* activate ADC */
  ADC_Init();

  /* forever */
  for(;;) {
  
    /* read ADC */
    Data = ADC_Read(0x87);	  // right justified, unsigned, channel AN07
    
    /* determine LED bit pattern */
    for(i=0, led=0x00; i<(Data & 0x3FF); i += 0x3FF/8) {
      
      /* assemble LED bit pattern */
      led = led<<1 | 0x01;
      
    }

    /* set LED array to new value */
    PORTB = (char)led;

  }
}
