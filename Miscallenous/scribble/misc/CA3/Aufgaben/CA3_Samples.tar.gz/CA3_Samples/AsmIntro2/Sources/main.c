/*  Assembler Introduction 
    How C constructs translate into assembler

    Computerarchitektur 3
    (C) 2007 J. Friedrich, W. Zimmermann
    Hochschule Esslingen

    Author:  W.Zimmermann, July 18, 2007  
    
    Note: 
    The two values are input and the output is display via the CPU's
    serial communication interface (SCI). In the True Time Simulator
    open component TestTerm before starting the program.

*/

#include <hidef.h>                      // common defines and macros
#include <mc9s12dp256.h>                // derivative information


#pragma LINK_INFO DERIVATIVE "mc9s12dp256b"

//Some global signed and unsigned 8, 16 and 32 bit variables
char a08=1, c08=3;
int  a16=1, b16=2; 
volatile int c16=3;
long a32=1, b32=2, c32=3;

unsigned char cu08=3;
volatile unsigned int cu16=3;

int betrag(int x)
{   return x > 0 ? x : -x;    
}


void main(void)
{   c16 = a16 + b16;                    //Addition 16 bit
    c32 = a32 + b32;                    //Addition 32 bit
        
    c08 = (char) c16;                   //Conversion   signed 16 -->  8 bit
    c16 = c08;                          //Conversion   signed  8 --> 16 bit
    cu08 = (unsigned char) cu16;        //Conversion unsigned 16 -->  8 bit
    cu16 = cu08;                        //Conversion unsigned  8 --> 16 bit

    c16 = c16  >> 2;                    //Shift right   signed (arithmetic)
    cu16= cu16 >> 2;                    //Shift right unsigned (logic)
    
    c08 = c08 | 0x81;                   //Set bits 7 and 0 to one
    a08 = a08 & 0x7E;                   //Set bits 7 and 0 to zero
    
    c16 = a16 ^  b16;                   //Bitwise Exclusive OR
    c16 = a16 &  b16;                   //Bitwise AND
    c16 = a16 && b16;                   //Logical AND

    if (c16 <= 32)                      //if - else
    {   a08 = 4;
    } else
    {   a08 = 8;
    }
    
    if (cu16 <= 32)                     //if -else
    {   a08 = 4;
    } else
    {   a08 = 8;
    }
  
    for (c08=0; c08 < 3; c08++)         //for
    {   c16 = c16 + a16;
    }
    

    while (c08 <= 32)                   //while
    {   a16++;
    } 

    do                                  //do - while
    {   a16++;
    } while (c08 <= 32);

    c16 = betrag(a16);                 //function call with single parameter

    for (;;);                          //endless loop
}

