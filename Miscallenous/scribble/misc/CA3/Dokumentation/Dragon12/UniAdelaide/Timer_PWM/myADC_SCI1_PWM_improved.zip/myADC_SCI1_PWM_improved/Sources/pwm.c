/* pwm.c  --  Pulse Width Modulation on the 9S12  --  fw-03-05 */
/*                                                             */
/*            improved version : uses PWMSCL before PCK        */
/*            -> better resolution (PWMSCL can be chosen in 	 */
/*               steps of '2', i.e. '2', '4', '6', ... '512'   */
 

#include <mc9s12dp256.h>        /* derivative information */


/* define module-global variables */
static unsigned int  myPeriod;
static unsigned int  myDuty;
static unsigned char myChannel;       /* selected channel */
static unsigned char myPrecision;     /* precision flag (8 / 16) */


//******** PWM_SetPeriod *************** 
// Set period register of the chosen PWM channel
void PWM_SetPeriod(float period) {

float         basePERIOD = 1/24e6, currPeriod;
unsigned int  cascadeFactor;
unsigned int  useSCL = 1;
unsigned int  myPCK = 0;          /* PCK[0-2] can range from 0 to 7  ==>  prescale values /1 ... /128 */
unsigned int  myPWMSCL = 1;       /* PWMSCL[0-7] can range from 1 to 256 */

	/* check if we need to cascade timers... */
	if(myPrecision == 16) cascadeFactor = 256;
  else                  cascadeFactor = 1;		

  /* check if we need scaling at all... */
  if(period <= basePERIOD*256*(cascadeFactor)) {
    
    /* not using (SA) clock -> reset corresponding bit */
    PWMCLK &= ~(1 << myChannel);
    
  } else {
    
    /* using (SA) clock -> set corresponding bit */
    PWMCLK |= (1 << myChannel);

  	/* determine period settings */
    useSCL = 2;         /* implicit factor '2' of the S(caled) clock */
    do {

      if(myPWMSCL < 256) {
 	  
	      myPWMSCL++;
      
      } else {
      
        /* reached the end of what's possible with the S-clock alone -> need prescaling */
        myPCK++;
        
        /* safeguard against too large period values */
        if(myPCK == 8) {
          myPCK = 7;     /* this is the slowest we can get... */
          break;
        }
      
      }
    
      /* note : basePERIOD has to be first to expand this to a float... 
                otherwise currPeriod will always be '0' */
      currPeriod = basePERIOD*256*(cascadeFactor)*(1<<myPCK)*useSCL*myPWMSCL;
        
    } while(period > currPeriod);

  } /* using S(A) clock */

  /* determine period value */
  myPeriod = (unsigned int)(period/(basePERIOD*256*(cascadeFactor)*(1<<myPCK)*useSCL*myPWMSCL) * 256*(cascadeFactor));
	
  /* factor 256 is represented by PWMSCL = 0 */
  if(myPWMSCL == 256) myPWMSCL = 0;


  switch(myChannel) {
    
    case 0:
    case 1:
    case 4:
    case 5:
      /* Set PWM 'scaled clock' bit (SA) - even it it isn't used... */
      PWMSCLA = (char)myPWMSCL;

      /* Set PWM clock A prescaler */
      PWMPRCLK &= 0xF0;
      PWMPRCLK |= myPCK;
      break;
    case 2:
    case 3:
    case 6:
    case 7:
      /* Set PWM 'scaled clock' bit (SB) - even it it isn't used... */
      PWMSCLB = (char)myPWMSCL;

      /* Set PWM clock B prescaler */
      PWMPRCLK &= 0x0F;
      PWMPRCLK |= (myPCK << 4);
      break;
  }
    

  /* set period register */
  if(myPrecision == 8) {
    
    /* 8-bit PWM */
    switch(myChannel) {
    
    case 0:
       PWMPER0 = (char)myPeriod;
       break;
    case 1:
       PWMPER1 = (char)myPeriod;
       break;
    case 2:
       PWMPER2 = (char)myPeriod;
       break;
    case 3:
       PWMPER3 = (char)myPeriod;
       break;
    case 4:
       PWMPER4 = (char)myPeriod;
       break;
    case 5:
       PWMPER5 = (char)myPeriod;
       break;
    case 6:
       PWMPER6 = (char)myPeriod;
       break;
    case 7:
       PWMPER7 = (char)myPeriod;

    }
    
  } else {
    
    /* 16-bit PWM */
    switch(myChannel) {
    
    case 1:
       PWMPER01 = myPeriod;
       break;
    case 3:
       PWMPER23 = myPeriod;
       break;
    case 5:
       PWMPER45 = myPeriod;
       break;
    case 7:
       PWMPER67 = myPeriod;

    }
    
  }
  
}

//******** PWM_SetDuty *************** 
// Set duty cycle register of the chosen PWM channel
void PWM_SetDuty(float duty) {

  /* work out interger duty cycle */
  myDuty = (unsigned int)(duty*myPeriod);
  
  /* set period register */
  if(myPrecision == 8) {
    
    /* 8-bit PWM */
    switch(myChannel) {
    
    case 0:
       PWMDTY0 = (char)myDuty;
       break;
    case 1:
       PWMDTY1 = (char)myDuty;
       break;
    case 2:
       PWMDTY2 = (char)myDuty;
       break;
    case 3:
       PWMDTY3 = (char)myDuty;
       break;
    case 4:
       PWMDTY4 = (char)myDuty;
       break;
    case 5:
       PWMDTY5 = (char)myDuty;
       break;
    case 6:
       PWMDTY6 = (char)myDuty;
       break;
    case 7:
       PWMDTY7 = (char)myDuty;

    }
    
  } else {
    
    /* 16-bit PWM */
    switch(myChannel) {
    
    case 1:
       PWMDTY01 = myDuty;
       break;
    case 3:
       PWMDTY23 = myDuty;
       break;
    case 5:
       PWMDTY45 = myDuty;
       break;
    case 7:
       PWMDTY67 = myDuty;

    }
    
  }
  
}


//******** PWM_Init *************** 
// Initialize PWM unit
void PWM_Init(unsigned char channel, unsigned char precision, float period) {

  /* initialize 'myPrecision' requested precision (8 / 16) */
  myPrecision = precision;
  
  /* concatenate PWM units to allow for 16-bit operation */
  if(precision == 16) {
  
    switch(channel) {
      
      case 0:
      case 1:
        PWMCTL |= 0x10;     // set CON01
        myChannel = 1;
        break;
      case 2:
      case 3:
        PWMCTL |= 0x20;     // set CON23
        myChannel = 3;
        break;
      case 4:
      case 5:
        PWMCTL |= 0x40;     // set CON45
        myChannel = 5;
        break;
      case 6:
      case 7:
        PWMCTL |= 0x80;     // set CON67
        myChannel = 7;
    }
    
  }
      

  /* Set PWM initial polarity bit to '1' */
  PWMPOL |= (1 << channel);

  /* set initial period */
  PWM_SetPeriod(period);

  /* set initial duty cycle (50%) */
  PWM_SetDuty(0.5);
  
  /* enable PWM on chosen channel */
  PWME |= (1 << channel);
  
}
