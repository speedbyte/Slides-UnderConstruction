/**********************************************************************************/
/* Header file ADC.h                                                              */
/**********************************************************************************/
#ifndef _ADC_H_
#define _ADC_H_



/* declare initialisation function ADC_InitN */
extern void ADC_InitN(unsigned char num);


/* declare read function ADC_ReadN */
extern void ADC_ReadN(unsigned char firstchan, unsigned char num, unsigned int *results);



#endif _ADC_H_
