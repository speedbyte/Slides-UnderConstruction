/* pwm.c  --  Pulse Width Modulation on the 9S12  --  fw-03-05 */
/*                                                             */
/*            improved version : uses PWMSCL before PCK        */
/*            -> better resolution (PWMSCL can be chosen in 	 */
/*               steps of '2', i.e. '2', '4', '6', ... '512'   */
 
#include <mc9s12dp256.h>        /* derivative information */

/* precisionFlags.i is 1 if channel i is 16-bit */
static unsigned char precisionFlags;

//******** PWM_SetPeriod *************** 
// Set period register of the chosen PWM channel
// channel is one of 0 through 7
// period is in seconds
void PWM_SetPeriod(unsigned char channel, float period) {

unsigned int  myPeriod;
float         basePERIOD = 1.0f/24e6f, currPeriod;
unsigned int  cascadeFactor;
unsigned int  useSCL = 1;
unsigned int  myPCK = 0;       /* PCK[0-2] can range from 0 to 7  ==>  prescale values /1 ... /128 */
unsigned int  myPWMSCL = 1;    /* PWMSCL[0-7] can range from 1 to 256 */

	/* check if we need to cascade timers... */
	if(precisionFlags & (1 << channel)) { // 16-bit
	  cascadeFactor = 256;
	  if(channel == 0
	     || channel == 2
	     || channel == 4
	     || channel == 6) {
      channel++;
    }
	} else { // 8-bit
	  cascadeFactor = 1;
	}

  /* check if we need scaling at all... */
  if(period <= basePERIOD*256*(cascadeFactor)) {
    
    /* not using (SA) clock -> reset corresponding bit */
    PWMCLK &= ~(1 << channel);
    
  } else {
    
    /* using (SA) clock -> set corresponding bit */
    PWMCLK |= (1 << channel);

  	/* determine period settings */
    useSCL = 2;         /* implicit factor '2' of the S(caled) clock */
    do {

      if(myPWMSCL < 256) {
 	  
	      myPWMSCL++;
      
      } else {
      
        /* reached the end of what's possible with the S-clock alone -> need prescaling */
        myPCK++;
        
        /* safeguard against too large period values */
        if(myPCK == 8) {
          myPCK = 7;     /* this is the slowest we can get... */
          break;
        }
      
      }
    
      /* note : basePERIOD has to be first to expand this to a float... 
                otherwise currPeriod will always be '0' */
      currPeriod = basePERIOD*256*(cascadeFactor)*(1<<myPCK)*useSCL*myPWMSCL;
        
    } while(period > currPeriod);

  } /* using S(A) clock */

  /* determine period value */
  myPeriod = (unsigned int)(period/(basePERIOD*256*(cascadeFactor)*(1<<myPCK)*useSCL*myPWMSCL) * 256*(cascadeFactor));
	
  /* factor 256 is represented by PWMSCL = 0 */
  if(myPWMSCL == 256) myPWMSCL = 0;


  switch(channel) {
    
    case 0:
    case 1:
    case 4:
    case 5:
    
      /* Set PWM 'scaled clock' bit (SA) - even it it isn't used... */
      PWMSCLA = (char)myPWMSCL;

      /* Set PWM clock A prescaler */
      PWMPRCLK &= 0xF0;
      PWMPRCLK |= myPCK;
      break;
      
    case 2:
    case 3:
    case 6:
    case 7:
    
      /* Set PWM 'scaled clock' bit (SB) - even it it isn't used... */
      PWMSCLB = (char)myPWMSCL;

      /* Set PWM clock B prescaler */
      PWMPRCLK &= 0x0F;
      PWMPRCLK |= (myPCK << 4);
      break;
      
  }
    

  /* set period register */
  if(precisionFlags & (1 << channel)) {
  
    /* 16-bit PWM */
    switch(channel) {
    
    case 0:
    case 1:
       PWMPER01 = myPeriod;
       break;
    case 2:
    case 3:
       PWMPER23 = myPeriod;
       break;
    case 4:
    case 5:
       PWMPER45 = myPeriod;
       break;
    case 6:
    case 7:
       PWMPER67 = myPeriod;
    }
    
  } else {
    
    /* 8-bit PWM */
    switch(channel) {
    
    case 0:
       PWMPER0 = (char)myPeriod;
       break;
    case 1:
       PWMPER1 = (char)myPeriod;
       break;
    case 2:
       PWMPER2 = (char)myPeriod;
       break;
    case 3:
       PWMPER3 = (char)myPeriod;
       break;
    case 4:
       PWMPER4 = (char)myPeriod;
       break;
    case 5:
       PWMPER5 = (char)myPeriod;
       break;
    case 6:
       PWMPER6 = (char)myPeriod;
       break;
    case 7:
       PWMPER7 = (char)myPeriod;

    }
    
  }
  
}

//******** PWM_SetDuty *************** 
// Set duty cycle register of the chosen PWM channel
// channel is one of 0 through 7
// duty is the duty cycle as a percentage
void PWM_SetDuty(unsigned char channel, float duty) {

  /* set period register */
  if(precisionFlags & (1 << channel)) {
    
    /* 16-bit PWM */
    switch(channel) {
    
    case 0:
    case 1:
       PWMDTY01 = (unsigned int)(duty*PWMPER01);
       break;
    case 2:
    case 3:
       PWMDTY23 = (unsigned int)(duty*PWMPER23);
       break;
    case 4:
    case 5:
       PWMDTY45 = (unsigned int)(duty*PWMPER45);
       break;
    case 6:
    case 7:
       PWMDTY67 = (unsigned int)(duty*PWMPER67);

    }
    
  } else {
    
    /* 8-bit PWM */
    switch(channel) {
    
    case 0:
       PWMDTY0 = (char)(duty*PWMPER0);
       break;
    case 1:
       PWMDTY1 = (char)(duty*PWMPER1);
       break;
    case 2:
       PWMDTY2 = (char)(duty*PWMPER2);
       break;
    case 3:
       PWMDTY3 = (char)(duty*PWMPER3);
       break;
    case 4:
       PWMDTY4 = (char)(duty*PWMPER4);
       break;
    case 5:
       PWMDTY5 = (char)(duty*PWMPER5);
       break;
    case 6:
       PWMDTY6 = (char)(duty*PWMPER6);
       break;
    case 7:
       PWMDTY7 = (char)(duty*PWMPER7);

    }

  }
  
}


//******** PWM_Init *************** 
// Initialize PWM unit
// channel is one of 0 through 7
// if(precision == 0) then 8-bit precision
// if(precision != 0) then 16-bit precision
// period in seconds
void PWM_Init(unsigned char channel,
              unsigned char precision,
              float period,
              float duty) {


  /* update appropriate bit in precisionFlags to match the requested precision (8 / 16) */
  if(precision) {
  
    if(   channel == 0
       || channel == 2
       || channel == 4
       || channel == 6) {
       
      channel++;
      
    }
    
    precisionFlags |= (1 << channel);
    precisionFlags |= (1 << (channel - 1));    
    
  } else {
  
    precisionFlags &= ~(1 << channel);
    
  }
  
  /* concatenate PWM units to allow for 16-bit operation */
  if(precision) {

		/* precision is 16-bit */
    switch(channel) {
      
      case 1:
        PWMCTL |= 0x10;     // set CON01
        break;
      case 3:
        PWMCTL |= 0x20;     // set CON23
        break;
      case 5:
        PWMCTL |= 0x40;     // set CON45
        break;
      case 7:
        PWMCTL |= 0x80;     // set CON67
        
    }
    
  } else {
    
		/* precision is 8-bit */
    // ensure appropriate CON flag is cleared
    switch(channel) {

      case 0:
      case 1:
        PWMCTL &= 0xEF;     // clear CON01
        break;
      case 2:
      case 3:
        PWMCTL &= 0xDF;     // clear CON23
        break;
      case 4:
      case 5:
        PWMCTL &= 0xBF;     // clear CON45
        break;
      case 6:
      case 7:
        PWMCTL &= 0x7F;     // clear CON67
    }
    
  }
      

  /* Set PWM initial polarity bit to '1' */
  PWMPOL |= (1 << channel);

  /* set initial period */
  PWM_SetPeriod(channel, period);

  /* set initial duty cycle */
  PWM_SetDuty(channel, duty);
  
  PWME |= (1 << channel);
  
}
