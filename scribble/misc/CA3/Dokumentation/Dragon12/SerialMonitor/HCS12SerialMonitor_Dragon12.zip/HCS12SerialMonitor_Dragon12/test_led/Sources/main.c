/* Example program for the Wytec Dragon 12 (MC9S12DP256B) */

#include <hidef.h>              /* common defines and macros */
#include <mc9s12dp256.h>        /* derivative information */


void main(void) {

  DDRB  = 0xff;       // Port B is output
  PORTB = 0xff;       // all LEDs on

  /* forever */
  for(;;){}
}
