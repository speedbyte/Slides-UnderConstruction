/*  Addieren1

    Computerarchitektur 3
    (C) 2007 J. Friedrich, W. Zimmermann
    Hochschule Esslingen

    Author:  W.Zimmermann, June 08, 2007  
             (based on code provided by J. Friedrich)
*/

#include <hidef.h>                      //Common defines
#include <mc9s12dp256.h>                //CPU specific defines


#pragma LINK_INFO DERIVATIVE "mc9s12dp256b"


#define TYPE char       //Set to char, int or long


#if 1                   //Set to 0 if you want to use local variables

//##### Version with global variables #########################################

TYPE a, b, c;

TYPE main(void)
{   
    EnableInterrupts;
    
    a = 10;
    b = 20;
    c = a+b;
    return c;
}

#else

//##### Version with local variables ##########################################

TYPE main(void)
{   TYPE a, b, c;

    EnableInterrupts;

    a = 10;
    b = 20;
    c = a+b;
    return c;
}

#endif

