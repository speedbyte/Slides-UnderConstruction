/**********************************************************************************/
/* Header file timer.h                                                            */
/**********************************************************************************/
#ifndef _TIMER_H_
#define _TIMER_H_



/* declare initialisation function TOC7_Init */
extern void TOC7_Init(void);


/* declare interrupt service routine TOC7_ISR */
extern __interrupt void TOC7_ISR(void);



#endif _TIMER_H_
