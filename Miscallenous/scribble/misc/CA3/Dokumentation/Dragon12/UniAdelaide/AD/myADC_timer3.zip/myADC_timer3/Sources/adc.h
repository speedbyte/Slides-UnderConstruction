/**********************************************************************************/
/* Header file ADC.h                                                              */
/**********************************************************************************/
#ifndef _ADC_H_
#define _ADC_H_


/* declare global variable ADC_Data */
extern unsigned int ADC_Data;


/* declare initialisation function ADC_Init */
extern void ADC_Init(void);

/* declare read function ADC_Read */
extern unsigned short ADC_Read(void);

/* declare read function ADC_Start */
extern void ADC_Start(unsigned short chan);

/* declare interrupt service routine ADC_ISR */
extern __interrupt void ADC_ISR(void);


#endif _ADC_H_
