/* Example program for the Wytec Dragon 12 (MC9S12DP256C) */

#include <mc9s12dp256.h>        /* derivative information */
#include "pll.h"								/* defines _BUSCLOCK, sets bus frequency to _BUSCLOCK MHz */
#include "adc.h"                /* ADC_Init, ADC_Read */


void main(void) {

unsigned int  i;
unsigned char led;

  /* set system clock frequency to _BUSCLOCK MHz (24 or 4) */
  PLL_Init();

  /* set port B as output (LEDs) */
  DDRB  = 0xff;       // Port B is output

  /* activate and start ADC */
  ADC_Init();

  /* allow all interrupts to take place */
  asm cli

  /* forever */
  for(;;) {
  
    /* determine LED bit pattern */
    for(i=0, led=0x00; i<(ADC_Data & 0x3FF); i += 0x3FF/8) {
      
      /* assemble LED bit pattern */
      led = led<<1 | 0x01;
      
    }

    /* set LED array to new value */
    PORTB = (char)led;

  }
}