/**********************************************************************************/
/* Header file PWM.h                                                              */
/**********************************************************************************/
#ifndef _PWM_H_
#define _PWM_H_

/* declare public functions */
extern void PWM_Init(unsigned char channel,
                     unsigned char precision,
                     float period,
                     float duty);
extern void PWM_SetPeriod(unsigned char channel,
                          float period);
extern void PWM_SetDuty(unsigned char channel,
                        float duty);

#endif _PWM_H_
