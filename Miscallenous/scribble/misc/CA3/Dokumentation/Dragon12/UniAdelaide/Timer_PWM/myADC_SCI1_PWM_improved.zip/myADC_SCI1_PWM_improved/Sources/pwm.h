/**********************************************************************************/
/* Header file PWM.h                                                              */
/**********************************************************************************/
#ifndef _PWM_H_
#define _PWM_H_

/* declare public functions */
extern void PWM_Init(unsigned char channel, unsigned char precision, float period);
extern void PWM_SetPeriod(float period);
extern void PWM_SetDuty(float duty);

#endif _PWM_H_
