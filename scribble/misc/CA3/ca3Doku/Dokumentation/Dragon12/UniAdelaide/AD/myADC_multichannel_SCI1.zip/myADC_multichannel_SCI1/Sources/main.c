/* Example program for the Wytec Dragon 12 (MC9S12DP256C) */

#include <mc9s12dp256.h>        /* derivative information */
#include <math.h>               /* fabs */
#include "pll.h"								/* defines _BUSCLOCK, sets bus frequency to _BUSCLOCK MHz */
#include "adc.h"                /* ADC_Init, ADC_Read */
#include "sci1.h"               /* support for SCI1 */

#define  firstChannel     2
#define  numChannels      3

void main(void) {

unsigned int  Data[8], DataSum, DataOld, i;
int           DataDiff;
char          myTxt[4] = "0: ";

  /* set system clock frequency to _BUSCLOCK MHz (24 or 4) */
  PLL_Init();

  /* initialise serial communication interface SCI1 */
  SCI1_Init(BAUD_115200);   // capped at 9600, if PLL inactive (4 MHz bus)
  
  /* test output on SCI1 */
  SCI1_OutString("Data logger\n\r");

  /* activate multichannel ADC */
  ADC_InitN(numChannels);

    
  /* forever */
  for(;;) {

    /* read ADC */
    ADC_ReadN(firstChannel, numChannels, Data);	    // channels 2, 3, 4 into Data[]
    
    /* get new channel sum */
    DataSum = 0;
    for(i=0; i<numChannels; i++) DataSum += Data[i];
    
    DataDiff = DataSum - DataOld;
    
    if(fabs(DataDiff) > 5) {
    
      DataOld = DataSum;
      
      SCI1_OutString("-------------------------\n\r");

      for(i=0; i<numChannels; i++) {
        
        SCI1_OutString("Current value AD channel ");
        myTxt[0] = (char)('0' + firstChannel + i);
        SCI1_OutString(myTxt);
        SCI1_OutUHex(Data[i]);
        SCI1_OutString("\n\r");
        
      } /* for */

    } /* if */
    
  } /* forever */
  
}
