/* Example program for the Wytec Dragon 12 (MC9S12DP256C) */

#include <mc9s12dp256.h>        /* derivative information */
#include <math.h>               /* fabs() */
#include "pll.h"								/* defines _BUSCLOCK, sets bus frequency to _BUSCLOCK MHz */
#include "adc.h"								/* ADC functions, result variable ADC_Data */
#include "sci1.h"               /* support for SCI1 */


void main(void) {

unsigned int  DataOld;
int           DataDiff;

  /* set system clock frequency to _BUSCLOCK MHz (24 or 4) */
  PLL_Init();

  DDRB  = 0xff;       // Port B is output
  PORTB = 0x00;       // switch off all LEDs 
  
  /* initialise serial communication interface SCI1 */
  SCI1_Init(BAUD_115200);   // capped at 9600, if PLL inactive (4 MHz bus)
  
  /* test output on SCI1 */
  SCI1_OutString("Data logger\n\r");

  /* activate ADC, allow interrupts to happen */
  ADC_Init();
  asm cli

  
  /* forever */
  for(;;) {

    DataDiff = ADC_Data - DataOld;
    
    if(fabs(DataDiff) > 5) {
      
      DataOld = ADC_Data;

      PORTB ^= 0x01;          // toggle port B bit 0
      SCI1_OutString("Current value AD channel 0: "); 
      SCI1_OutUHex(ADC_Data);
      SCI1_OutString("\n\r");
      
    }
    
  }
  
}
