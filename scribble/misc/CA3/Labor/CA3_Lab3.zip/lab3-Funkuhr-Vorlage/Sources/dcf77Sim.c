/*  Simulation von DCF77 Rechtecksignalen
    Zum Testen der Funkuhr mit dem Simulator oder mit dem Dragon12-Entwicklungsboard,
    wenn kein DCF77-Funkempf�nger vorhanden ist.
    
    Computerarchitektur 3
    (C) 2007 J. Friedrich, W. Zimmermann
    Hochschule Esslingen

    Author:  W.Zimmermann, Aug. 09, 2007 
    
    Die Funktion readPort() muss periodisch genau einmal alle 10ms aufgerufen werden
    und liefert den Signalwert des DCF77-Signals. Die Uhrzeit wiederholt sich nach 8 Minuten.
*/


long dcf77Data[16] = 
{   0x42540000, 0x001D1914,		// DCF77 simulation data 	22.13h 11.08.2007
    0x52740000, 0x001D1914,
    0x42940000, 0x001D1914,
    0x52B40000, 0x001D1914,
    0x52D40000, 0x001D1914,
    0x42F40000, 0x001D1914,
    0x43140000, 0x001D1914,
    0x53340000, 0x001D1914		//				22.20h 11.08.2007
};
int dcf77DataMin = 8;			// ... for 8 minutes

char readPortSim(void)
{   static int i10ms = 9;		// Time counter, counts  10ms increments of a 100ms period
    static int i100ms =9;		//		 counts 100ms increments of a 1s    period
    static int iSec  = 50;		//               counts 1s    increments of a 1min  period
    static int iMin  = 0;
    char signal = 0x01;			// Default output signal is a High
    
    i10ms  = (i10ms +1) % 10;		// Update the time counters
    if (i10ms == 0)
    {  	i100ms = (i100ms+1) % 10;
    	if (i100ms == 0)
    	{   iSec = (iSec + 1) % 60;
    	    if (iSec == 0)
    	    	iMin = (iMin + 1) % 60;
    	}
    	
    }
    
    if (iSec < 59)			// If it is not the last second of a minute
    {   if (i100ms < 1)			// ... and if we are at the first 100ms of a second
        {   signal = 0;			// ...... output Low 
    	} else if (i100ms < 2)		// ... if we are at the second 200ms of a second
    	{   char n = (char) (iMin % dcf77DataMin);	
    	    char i = (char) (iSec / 32);		
    	    char j = (char) (iSec % 32);
    	    long temp = dcf77Data[n*2+i];
    	    temp = (temp >> j) & 0x01;
    	    if (temp)			// ...... and if the data bit is 1 output another Low
		signal = 0;    	    
    	}
    }
    return signal;	
}

void initializePortSim(void)
{
}